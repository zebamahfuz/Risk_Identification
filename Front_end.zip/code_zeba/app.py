from flask import Flask, request, render_template, redirect, url_for
import boto3
import joblib
import pandas as pd
import io

app = Flask(__name__)

# AWS S3 configuration
BUCKET_NAME = 'zebasbucket'
MODEL_KEY = 'models/mlp_classifier.pkl'

# Initialize S3 client
s3 = boto3.client('s3')

# Function to load model from S3
def load_model():
    s3_object = s3.get_object(Bucket=BUCKET_NAME, Key=MODEL_KEY)
    model_data = s3_object['Body'].read()
    return joblib.load(io.BytesIO(model_data))

# Load model
model = load_model()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get form data
        data = {
            'duration': [int(request.form['duration'])],
            'protocol_type': [request.form['protocol_type']],
            'service': [request.form['service']],
            'flag': [request.form['flag']],
            'src_bytes': [int(request.form['src_bytes'])],
            'dst_bytes': [int(request.form['dst_bytes'])],
            'land': [int(request.form['land'])],
            'wrong_fragment': [int(request.form['wrong_fragment'])],
            'urgent': [int(request.form['urgent'])],
            'hot': [int(request.form['hot'])],
            'dst_host_same_srv_rate': [float(request.form['dst_host_same_srv_rate'])],
            'dst_host_diff_srv_rate': [float(request.form['dst_host_diff_srv_rate'])],
            'dst_host_same_src_port_rate': [float(request.form['dst_host_same_src_port_rate'])],
            'dst_host_srv_diff_host_rate': [float(request.form['dst_host_srv_diff_host_rate'])],
            'dst_host_serror_rate': [float(request.form['dst_host_serror_rate'])],
            'dst_host_srv_serror_rate': [float(request.form['dst_host_srv_serror_rate'])],
            'dst_host_rerror_rate': [float(request.form['dst_host_rerror_rate'])],
            'dst_host_srv_rerror_rate': [float(request.form['dst_host_srv_rerror_rate'])],
            'outcome': [request.form['outcome']],
            'level': [int(request.form['level'])]
        }

        # Convert to DataFrame
        df = pd.DataFrame(data)
        
        # If necessary, perform encoding or other preprocessing
        df_encoded = pd.get_dummies(df)

        # Make prediction
        prediction = model.predict(df_encoded)
        
        return render_template('index.html', prediction=prediction[0])

    return render_template('index.html', prediction=None)

if __name__ == '__main__':
    app.run(debug=True)
